# 译影 TranslateVision — Android 手机端原生版本

这是面向 Android 手机的原生 App 工程，不要求电脑常驻运行 Python 服务。语音识别在手机端通过 **whisper.cpp**（Whisper 模型的 C/C++ 推理实现）运行，日语转简体中文使用 Google ML Kit Translation 的设备端模型；模型下载完成后，翻译可在设备本地执行，不需要付费 API Key。

> 重要：这不是 faster-whisper 本身。faster-whisper 依赖 CTranslate2，不能直接作为 Android Kotlin 库使用。本工程改用可通过 Android NDK 编译的 whisper.cpp，实现本地 Whisper 识别。若必须逐字保持 faster-whisper/CTranslate2，则需要额外进行 CTranslate2 Android 移植，不能把桌面 Python 包直接塞进 APK。

## 当前工程包含

- Kotlin + Jetpack Compose 手机界面。
- Media3 本地视频播放器。
- WebView 网页播放器入口。
- Android AudioPlaybackCapture 音频捕获入口（系统 MediaProjection 授权）。
- whisper.cpp JNI 推理桥接，CMake 在构建时拉取 whisper.cpp v1.7.5；JNI 层缓存模型上下文，避免每个音频片段重复加载模型。
- ML Kit 日语→简体中文设备端翻译。
- 译文区域只显示中文，不显示日语识别原文。

## 环境要求

- Android Studio（建议近期稳定版）
- JDK 17
- Android SDK 35
- Android NDK + CMake 3.22.1
- 首次 Gradle/CMake 构建需要网络，以获取依赖和 whisper.cpp 源码
- 建议真机 Android 10（API 29）或更高版本

## Whisper 模型

首次启动前准备一个 **whisper.cpp/GGML 格式**模型，例如 `ggml-small.bin` 或 `ggml-base.bin`。将模型文件复制到手机后，在 App 内点“导入模型”选择它。模型会复制到 App 私有目录并命名为 `ggml-model.bin`。

- `base`：占用较少、速度较快，但识别准确率相对低。
- `small`：准确率与性能较均衡，建议先试。
- `medium`：对手机内存和算力要求明显更高，不建议作为默认模型。

模型文件体积较大，未打包进源码 ZIP 或 APK。请从 whisper.cpp 官方模型说明/可信来源获取 GGML 模型，并遵守模型许可条款。

## 构建

1. 解压 ZIP，在 Android Studio 中打开 `TranslateVision` 文件夹。
2. 安装 Android SDK 35、NDK 和 CMake 3.22.1。
3. 等待 Gradle 同步与 CMake 配置完成（首次构建会下载 whisper.cpp）。
4. 连接 Android 手机，点 Run；或使用 Build → Build APK(s)。
5. 将 GGML 模型导入 App，播放视频后点“开始捕获音频”，按系统提示授权。

## 重要限制

- 本工程目前是可继续构建和联调的原生工程初版；此运行环境没有 Android SDK/NDK 和 Gradle，因此没有声称 APK 已经成功编译或真机通过。
- 当前捕获链路已改为 4 秒识别窗口、3 秒步进并保留 1 秒重叠，减少短片段识别造成的断词；仍需完善 VAD、字幕去重/拼接、前台服务、后台持续运行和温控策略。
- Android 的跨 App 音频捕获只支持来源 App 允许被捕获的媒体/游戏音频；受保护视频、通话、部分浏览器/播放器或厂商系统可能禁止捕获。系统每次可能要求用户授权。
- WebView 音频是否可捕获取决于网页播放器及 Android 音频策略；不能保证所有网页都可用。
- ML Kit 首次使用需要下载日语和中文翻译模型；下载后在本地翻译。它不是完全预置模型的零网络安装包。
- 当前版本还未完成悬浮字幕、后台持续运行、词级时间戳、字幕历史和模型自动下载管理。

## 隐私

音频识别在手机本地执行。ML Kit 翻译模型首次下载需要网络，但待翻译文本由设备端模型处理；工程不配置第三方付费翻译 API。请只捕获自己有权处理的音视频内容。
