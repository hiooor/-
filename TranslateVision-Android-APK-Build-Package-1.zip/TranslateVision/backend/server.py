from __future__ import annotations

import io
import os
import tempfile
from functools import lru_cache
from typing import Optional

import numpy as np
import soundfile as sf
from fastapi import FastAPI, HTTPException, Request
from faster_whisper import WhisperModel

APP_NAME = "TranslateVision local speech service"
MODEL_SIZE = os.getenv("WHISPER_MODEL", "small")
DEVICE = os.getenv("WHISPER_DEVICE", "auto")
COMPUTE_TYPE = os.getenv("WHISPER_COMPUTE_TYPE", "int8")
TRANSLATE_MODE = os.getenv("TRANSLATE_MODE", "argos")

app = FastAPI(title=APP_NAME)

@lru_cache(maxsize=1)
def get_model() -> WhisperModel:
    # Model files are downloaded once from Hugging Face on first run, then cached locally.
    return WhisperModel(MODEL_SIZE, device=DEVICE, compute_type=COMPUTE_TYPE)

def translate_zh(text: str) -> tuple[str, Optional[str]]:
    if not text.strip():
        return "", None
    if TRANSLATE_MODE == "none":
        return text, "当前使用原文回传模式；请安装日语到中文的 Argos 模型包。"
    try:
        import argostranslate.translate
        translated = argostranslate.translate.translate(text, "ja", "zh")
        if translated and translated != text:
            return translated, None
        return text, "未找到 ja→zh 翻译包，当前暂时显示识别原文。"
    except Exception as exc:
        return text, f"本地翻译不可用：{exc}"

@app.get("/health")
def health():
    return {"ok": True, "model": MODEL_SIZE, "device": DEVICE, "translation": TRANSLATE_MODE}

@app.post("/transcribe")
async def transcribe(request: Request):
    raw = await request.body()
    if not raw:
        raise HTTPException(status_code=400, detail="empty audio body")
    try:
        audio, sample_rate = sf.read(io.BytesIO(raw), dtype="float32", always_2d=False)
        if audio.ndim == 2:
            audio = audio.mean(axis=1)
        if sample_rate != 16000:
            # Android client sends 16 kHz PCM WAV; this guards malformed clients.
            import librosa
            audio = librosa.resample(audio, orig_sr=sample_rate, target_sr=16000)
        segments, info = get_model().transcribe(
            audio,
            language="ja",
            task="transcribe",
            beam_size=3,
            vad_filter=True,
            condition_on_previous_text=False,
            temperature=0.0,
        )
        text = "".join(segment.text for segment in segments).strip()
        translation, warning = translate_zh(text)
        return {
            "text": text,
            "translation": translation or "（未识别到语音）",
            "language": info.language,
            "language_probability": info.language_probability,
            "warning": warning,
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"processing failed: {exc}") from exc
