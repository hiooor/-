# 译影本地识别服务

## 环境
- Windows 10/11、macOS 或 Linux
- Python 3.10–3.12
- 建议 8 GB 以上内存；有 NVIDIA GPU 时可配置 CUDA
- 手机和电脑连接同一个 Wi-Fi

## 安装

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python install_argos_ja_zh.py
```

首次启动 faster-whisper 时会下载模型文件并缓存在本机。默认 `small + int8`，准确率和速度相对均衡。

```bash
uvicorn server:app --host 0.0.0.0 --port 8000
```

允许系统防火墙放行 TCP 8000。手机 App 的“电脑端服务地址”填写电脑局域网 IP，例如 `http://192.168.1.23:8000`。

## 模型设置

默认环境变量：
- `WHISPER_MODEL=small`：可选 `tiny`、`base`、`small`、`medium`、`large-v3`。越大通常越准但更慢、更占内存。
- `WHISPER_DEVICE=auto`：自动选择设备；可设置 `cpu` 或 `cuda`。
- `WHISPER_COMPUTE_TYPE=int8`：CPU 推荐 int8；CUDA 可按环境改为 float16。
- `TRANSLATE_MODE=argos`：使用本地 Argos Translate 日语→简体中文模型，不需要 API Key。

如果 Argos 模型下载/安装失败，服务仍可识别日语，但会暂时回传识别原文并在 API 响应中给出 warning。

## API
- `GET /health`：服务状态
- `POST /transcribe`：请求体为 16 kHz、单声道、PCM16 WAV；返回 `text`、`translation` 等字段。

音频只在手机与这台电脑之间的局域网传输，不发送到云端 API。首次安装模型需要联网下载权重和翻译包。
