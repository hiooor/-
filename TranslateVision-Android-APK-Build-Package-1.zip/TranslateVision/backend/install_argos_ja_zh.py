"""Install the Argos Translate Japanese -> Simplified Chinese package locally."""
import argostranslate.package
import argostranslate.translate

available = argostranslate.package.get_available_packages()
package = next((p for p in available if p.from_code == "ja" and p.to_code == "zh"), None)
if package is None:
    raise SystemExit("No ja->zh Argos package was found in the current package index.")
path = package.download()
argostranslate.package.install_from_path(path)
print("Installed local ja -> zh translation package.")
