# APK 构建说明

## 当前状态

本源码包尚未附带 APK。生成 APK 必须使用 Android SDK、Android NDK、CMake 和 Gradle。当前执行环境没有安装 Android SDK/NDK 或 Gradle，因此不能声称 APK 已编译成功。

## 在 Android Studio 中构建

1. 安装 Android Studio 和 JDK 17。
2. 打开本目录 `TranslateVision`。
3. 安装 Android SDK Platform 35、Build Tools 35.0.0、NDK 27.2.12479018、CMake 3.22.1。
4. 等待 Gradle 同步。首次原生构建需要联网下载 whisper.cpp v1.7.5。
5. 选择 `Build > Build Bundle(s) / APK(s) > Build APK(s)`。
6. APK 输出位置：`app/build/outputs/apk/debug/app-debug.apk`。

## 使用 GitHub Actions 构建

项目包含 `.github/workflows/android-apk.yml`：
1. 将整个项目目录推送到 GitHub 仓库。
2. 打开仓库的 Actions 页面。
3. 选择 `Build Android APK`，点击 `Run workflow`。
4. 构建成功后，在运行记录的 Artifacts 下载 `TranslateVision-debug-apk`。

## Android 17 兼容性提醒

当前工程配置使用 `compileSdk 35 / targetSdk 35`，尚非 Android 17/API 37 专项适配版本。先以可重复构建为目标；完成 API 级别验证后再升级 targetSdk，避免误报兼容。
