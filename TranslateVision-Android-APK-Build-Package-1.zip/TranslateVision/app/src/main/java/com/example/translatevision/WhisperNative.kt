package com.example.translatevision

object WhisperNative {
    init { System.loadLibrary("translatevision") }
    external fun transcribeNative(samples: FloatArray, modelPath: String, language: String = "ja"): String
}
