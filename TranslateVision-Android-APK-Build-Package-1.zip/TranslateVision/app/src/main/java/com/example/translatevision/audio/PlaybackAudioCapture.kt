package com.example.translatevision.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaProjection
import android.media.MediaRecorder
import android.os.Build
import androidx.annotation.RequiresApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Captures eligible playback from other apps. Android/source-app capture policies still apply. */
@RequiresApi(Build.VERSION_CODES.Q)
class PlaybackAudioCapture(
    private val projection: MediaProjection,
    private val scope: CoroutineScope,
    private val chunker: PcmChunker
) {
    private var job: Job? = null
    private var recorder: AudioRecord? = null

    fun start() {
        if (job != null) return
        val config = AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .build()
        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(16000)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        recorder = AudioRecord.Builder().setAudioFormat(format).setBufferSizeInBytes(maxOf(min, 8192))
            .setAudioPlaybackCaptureConfig(config).build()
        recorder?.startRecording()
        job = scope.launch(Dispatchers.IO) {
            val buffer = ByteArray(4096)
            while (isActive) {
                val n = recorder?.read(buffer, 0, buffer.size) ?: -1
                if (n > 0) chunker.push(buffer, n)
            }
        }
    }

    fun stop() {
        job?.cancel(); job = null
        runCatching { recorder?.stop() }
        recorder?.release(); recorder = null
        chunker.flush()
    }
}
