package com.example.translatevision.net

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class TranslationClient(private val baseUrl: String) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun translatePcm16(pcm: ByteArray, sampleRate: Int = 16000): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val wav = pcmToWav(pcm, sampleRate)
            val request = Request.Builder()
                .url("${baseUrl.trimEnd('/')}/transcribe")
                .post(wav.toRequestBody("audio/wav".toMediaType()))
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) error("识别服务错误：HTTP ${response.code}")
                val body = response.body?.string() ?: error("服务没有返回内容")
                JSONObject(body).optString("translation", "").ifBlank {
                    JSONObject(body).optString("text", "（未识别到语音）")
                }
            }
        }
    }

    suspend fun health(): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val req = Request.Builder().url("${baseUrl.trimEnd('/')}/health").build()
            client.newCall(req).execute().use { it.isSuccessful }
        }.getOrDefault(false)
    }

    private fun pcmToWav(pcm: ByteArray, sampleRate: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream(44 + pcm.size)
        fun writeInt(v: Int) { out.write(byteArrayOf(v.toByte(), (v shr 8).toByte(), (v shr 16).toByte(), (v shr 24).toByte())) }
        fun writeShort(v: Int) { out.write(byteArrayOf(v.toByte(), (v shr 8).toByte())) }
        out.write("RIFF".toByteArray()); writeInt(36 + pcm.size); out.write("WAVE".toByteArray())
        out.write("fmt ".toByteArray()); writeInt(16); writeShort(1); writeShort(1)
        writeInt(sampleRate); writeInt(sampleRate * 2); writeShort(2); writeShort(16)
        out.write("data".toByteArray()); writeInt(pcm.size); out.write(pcm)
        return out.toByteArray()
    }
}
