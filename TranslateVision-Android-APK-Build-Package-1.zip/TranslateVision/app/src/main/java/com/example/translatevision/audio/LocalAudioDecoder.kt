package com.example.translatevision.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.nio.ByteOrder

/** Decodes the selected local file's audio track to mono 16 kHz PCM and paces it approximately in real time. */
class LocalAudioDecoder(private val context: Context, private val chunker: PcmChunker) {
    suspend fun decode(uri: Uri) = withContext(Dispatchers.IO) {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                extractor.setDataSource(pfd.fileDescriptor)
                var audioTrack = -1
                var format: MediaFormat? = null
                for (i in 0 until extractor.trackCount) {
                    val f = extractor.getTrackFormat(i)
                    val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith("audio/")) { audioTrack = i; format = f; break }
                }
                if (audioTrack < 0 || format == null) error("视频文件中没有找到音轨")
                extractor.selectTrack(audioTrack)
                val mime = format.getString(MediaFormat.KEY_MIME)!!
                codec = MediaCodec.createDecoderByType(mime)
                codec!!.configure(format, null, null, 0)
                codec!!.start()
                val info = MediaCodec.BufferInfo()
                var inputDone = false
                var outputDone = false
                var sourceRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                var carry = ByteArray(0)
                var lastPtsUs = 0L
                while (!outputDone) {
                    if (!inputDone) {
                        val inputIndex = codec!!.dequeueInputBuffer(10_000)
                        if (inputIndex >= 0) {
                            val input = codec!!.getInputBuffer(inputIndex)!!
                            val size = extractor.readSampleData(input, 0)
                            if (size < 0) {
                                codec!!.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                val pts = extractor.sampleTime
                                codec!!.queueInputBuffer(inputIndex, 0, size, pts, 0)
                                extractor.advance()
                            }
                        }
                    }
                    when (val outputIndex = codec!!.dequeueOutputBuffer(info, 10_000)) {
                        MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val out = codec!!.outputFormat
                            sourceRate = out.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            channels = out.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        }
                        MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                        else -> if (outputIndex >= 0) {
                            val output = codec!!.getOutputBuffer(outputIndex)
                            if (output != null && info.size > 0) {
                                output.position(info.offset); output.limit(info.offset + info.size)
                                val bytes = ByteArray(info.size); output.get(bytes)
                                val mono = toMono16(bytes, channels)
                                val pcm16k = resample16k(mono, sourceRate)
                                if (pcm16k.isNotEmpty()) {
                                    chunker.push(pcm16k)
                                    val nowPts = info.presentationTimeUs
                                    val durationMs = if (lastPtsUs > 0 && nowPts > lastPtsUs) ((nowPts - lastPtsUs) / 1000).coerceIn(0, 500) else 0
                                    if (durationMs > 0) delay(durationMs)
                                    lastPtsUs = nowPts
                                }
                            }
                            outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                            codec!!.releaseOutputBuffer(outputIndex, false)
                        }
                    }
                }
                chunker.flush()
            } ?: error("无法读取所选文件")
        } finally {
            runCatching { codec?.stop() }; codec?.release(); extractor.release()
        }
    }

    private fun toMono16(bytes: ByteArray, channels: Int): ShortArray {
        val bb = java.nio.ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val samples = ShortArray(bytes.size / 2) { bb.short }
        if (channels <= 1) return samples
        val frames = samples.size / channels
        return ShortArray(frames) { i ->
            var sum = 0L
            for (c in 0 until channels) sum += samples[i * channels + c].toLong()
            (sum / channels).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
    }

    private fun resample16k(input: ShortArray, inputRate: Int): ByteArray {
        if (input.isEmpty() || inputRate <= 0) return ByteArray(0)
        val outCount = (input.size.toLong() * 16000L / inputRate).toInt().coerceAtLeast(1)
        val out = java.nio.ByteBuffer.allocate(outCount * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until outCount) {
            val pos = i.toDouble() * inputRate / 16000.0
            val a = pos.toInt().coerceIn(0, input.lastIndex)
            val b = (a + 1).coerceAtMost(input.lastIndex)
            val frac = pos - a
            val sample = (input[a] * (1.0 - frac) + input[b] * frac).toInt().coerceIn(-32768, 32767)
            out.putShort(sample.toShort())
        }
        return out.array()
    }
}
