package com.example.translatevision

import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max

class MainActivity : ComponentActivity() {
    private var projection: MediaProjection? = null
    private var captureThread: Thread? = null
    private var audioRecord: AudioRecord? = null
    private lateinit var projectionManager: MediaProjectionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        setContent { TranslateScreen() }
    }

    @Composable
    private fun TranslateScreen() {
        val context = LocalContext.current
        var status by remember { mutableStateOf("首次使用：请导入 Whisper 模型文件") }
        var translated by remember { mutableStateOf("中文译文将在这里显示") }
        var webUrl by remember { mutableStateOf("https://") }
        var selectedUri by remember { mutableStateOf<Uri?>(null) }
        var webVisible by remember { mutableStateOf(false) }
        var capturing by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()
        val player = remember { ExoPlayer.Builder(context).build() }
        DisposableEffect(Unit) { onDispose { stopCapture(); player.release() } }

        val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                runCatching {
                    contentResolver.openInputStream(uri)?.use { input -> File(filesDir, "ggml-model.bin").outputStream().use(input::copyTo) }
                    status = "模型已导入：${File(filesDir, "ggml-model.bin").length() / 1_000_000} MB"
                }.onFailure { status = "模型导入失败：${it.message}" }
            }
        }
        val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                selectedUri = uri
                runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                player.setMediaItem(MediaItem.fromUri(uri)); player.prepare(); player.playWhenReady = true
                status = "本地视频已开始播放。授权系统音频捕获后可尝试识别。"
            }
        }
        val projectionPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                projection = projectionManager.getMediaProjection(result.resultCode, result.data!!)
                projection?.let { startCapture(it, context, { status = it }, { japanese ->
                    scope.launch {
                        try {
                            val options = TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.JAPANESE).setTargetLanguage(TranslateLanguage.CHINESE).build()
                            val translator = Translation.getClient(options)
                            withContext(Dispatchers.IO) { Tasks.await(translator.downloadModelIfNeeded()) }
                            translated = withContext(Dispatchers.IO) { Tasks.await(translator.translate(japanese)) }
                            translator.close()
                        } catch (e: Exception) { status = "本地翻译失败：${e.message}" }
                    }
                }) }
                capturing = true
                status = "正在本机识别日语音频"
            } else status = "未授权音频捕获"
        }

        MaterialTheme(colorScheme = darkColorScheme()) {
            Surface(Modifier.fillMaxSize(), color = Color(0xFF101216)) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("译影 · 手机实时翻译", color = Color.White, fontSize = 24.sp)
                    Text("设备本地 Whisper 识别 → 中文译文", color = Color(0xFF9CA3AF), fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { modelPicker.launch(arrayOf("application/octet-stream", "*/*")) }) { Text("导入模型") }
                        Button(onClick = { videoPicker.launch(arrayOf("video/*", "audio/*")) }) { Text("选择视频") }
                    }
                    if (selectedUri != null) AndroidView(factory = { ctx -> PlayerView(ctx).apply { this.player = player } }, modifier = Modifier.fillMaxWidth().height(220.dp))
                    OutlinedButton(onClick = { webVisible = !webVisible }) { Text(if (webVisible) "关闭网页播放器" else "打开网页播放器") }
                    if (webVisible) {
                        OutlinedTextField(value = webUrl, onValueChange = { webUrl = it }, label = { Text("视频网页地址") }, modifier = Modifier.fillMaxWidth())
                        AndroidView(factory = { ctx -> WebView(ctx).apply { settings.javaScriptEnabled = true; webChromeClient = WebChromeClient(); webViewClient = WebViewClient(); loadUrl(webUrl) } }, modifier = Modifier.fillMaxWidth().height(300.dp))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(enabled = !capturing, onClick = { projectionPicker.launch(projectionManager.createScreenCaptureIntent()) }) { Text("开始捕获音频") }
                        OutlinedButton(enabled = capturing, onClick = { stopCapture(); capturing = false; status = "已停止" }) { Text("停止") }
                    }
                    Text(status, color = Color(0xFFB8C0CC), fontSize = 12.sp)
                    Text("实时中文译文", color = Color.White, fontSize = 18.sp)
                    Box(Modifier.fillMaxWidth().background(Color(0xFF20242B), RoundedCornerShape(12.dp)).padding(16.dp).defaultMinSize(minHeight = 130.dp)) {
                        Text(translated, color = Color.White, fontSize = 21.sp, lineHeight = 30.sp)
                    }
                    Text("模型需单独导入。其他 App 音频捕获受 Android 版本及来源 App 的录制策略限制；部分视频无法捕获。", color = Color(0xFF8993A2), fontSize = 11.sp)
                }
            }
        }
    }

    private fun startCapture(mp: MediaProjection, context: Context, report: (String) -> Unit, onJapanese: (String) -> Unit) {
        val config = AudioPlaybackCaptureConfiguration.Builder(mp)
            .add匹配()
            .build()
        val rate = 16000
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val recorder = AudioRecord.Builder().setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build())
            .setBufferSizeInBytes(max(min, rate * 2)).setAudioPlaybackCaptureConfig(config).build()
        audioRecord = recorder
        captureThread = Thread {
            try {
                recorder.startRecording()
                // AudioRecord may return arbitrary-sized reads. Accumulate 4-second
                // mono windows and advance by 3 seconds, retaining 1 second of context.
                // This avoids running Whisper on tiny fragments and reduces word clipping.
                val buffer = ShortArray(rate * 2) // stereo samples: up to ~1 second per read
                val windowSamples = rate * 4
                val hopSamples = rate * 3
                val pending = FloatArray(rate * 6)
                var pendingCount = 0
                val model = File(context.filesDir, "ggml-model.bin")
                if (!model.exists()) { report("请先导入 ggml Whisper 模型"); return@Thread }
                while (!Thread.currentThread().isInterrupted) {
                    val count = recorder.read(buffer, 0, buffer.size)
                    if (count > 0) {
                        var i = 0
                        while (i + 1 < count && pendingCount < pending.size) {
                            pending[pendingCount++] = ((buffer[i].toInt() + buffer[i + 1].toInt()) / 2) / 32768f
                            i += 2
                        }
                        while (pendingCount >= windowSamples) {
                            val window = pending.copyOfRange(0, windowSamples)
                            val text = WhisperNative.transcribeNative(window, model.absolutePath, "ja").trim()
                            if (text.isNotBlank()) onJapanese(text)
                            val remaining = pendingCount - hopSamples
                            System.arraycopy(pending, hopSamples, pending, 0, remaining)
                            pendingCount = remaining
                        }
                    } else if (count < 0) {
                        report("音频读取失败，错误码：$count")
                        break
                    }
                }
            } catch (e: Exception) { report("音频捕获错误：${e.message}") }
        }.also { it.start() }
    }

    private fun AudioPlaybackCaptureConfiguration.Builder.add匹配(): AudioPlaybackCaptureConfiguration.Builder =
        addMatchingUsage(android.media.AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(android.media.AudioAttributes.USAGE_GAME)

    private fun stopCapture() {
        captureThread?.interrupt(); captureThread = null
        runCatching { audioRecord?.stop(); audioRecord?.release() }
        audioRecord = null
        projection?.stop(); projection = null
    }
}
