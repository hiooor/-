package com.example.translatevision.audio

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream

/** Buffers mono PCM16 at 16 kHz and submits short overlapping chunks for low-latency recognition. */
class PcmChunker(
    private val scope: CoroutineScope,
    private val onChunk: suspend (ByteArray) -> Unit,
    private val chunkSeconds: Int = 4
) {
    private val lock = Any()
    private val buffer = ByteArrayOutputStream()
    private val targetBytes = 16000 * 2 * chunkSeconds
    private var lastTail = ByteArray(0)

    fun push(bytes: ByteArray, count: Int = bytes.size) {
        val ready: ByteArray?
        synchronized(lock) {
            buffer.write(bytes, 0, count)
            if (buffer.size() < targetBytes) return
            val current = buffer.toByteArray()
            val combined = lastTail + current
            ready = combined
            lastTail = current.copyOfRange((current.size - minOf(current.size, 16000 * 2 / 2)).coerceAtLeast(0), current.size)
            buffer.reset()
        }
        scope.launch(Dispatchers.IO) { onChunk(ready!!) }
    }

    fun flush() {
        val data = synchronized(lock) { buffer.toByteArray().also { buffer.reset() } }
        if (data.size > 16000) scope.launch(Dispatchers.IO) { onChunk(data) }
    }
}
