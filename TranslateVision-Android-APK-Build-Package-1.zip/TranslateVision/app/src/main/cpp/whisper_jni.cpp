#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include "whisper.h"

// Keep the Whisper context alive across audio windows. Loading model weights for
// every AudioRecord read would cause severe latency and memory churn.
static std::mutex g_whisper_mutex;
static whisper_context *g_whisper_ctx = nullptr;
static std::string g_model_path;

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_translatevision_WhisperNative_transcribeNative(
        JNIEnv *env, jobject, jfloatArray samples, jstring modelPath, jstring language) {
    const char *model = env->GetStringUTFChars(modelPath, nullptr);
    const char *lang = env->GetStringUTFChars(language, nullptr);
    const jsize n = env->GetArrayLength(samples);
    std::vector<jfloat> pcm(static_cast<size_t>(n));
    env->GetFloatArrayRegion(samples, 0, n, pcm.data());

    std::lock_guard<std::mutex> guard(g_whisper_mutex);
    if (!g_whisper_ctx || g_model_path != model) {
        if (g_whisper_ctx) whisper_free(g_whisper_ctx);
        g_whisper_ctx = nullptr;
        whisper_context_params cparams = whisper_context_default_params();
        cparams.use_gpu = false; // CPU baseline; mobile acceleration can be added after device profiling.
        g_whisper_ctx = whisper_init_from_file_with_params(model, cparams);
        g_model_path = model;
    }
    std::string result;
    if (g_whisper_ctx) {
        whisper_full_params params = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
        params.print_progress = false;
        params.print_realtime = false;
        params.print_timestamps = false;
        params.translate = false; // preserve Japanese transcription; Chinese translation is a separate local stage.
        params.language = lang;
        params.n_threads = 4;
        params.no_context = true;
        if (whisper_full(g_whisper_ctx, params, pcm.data(), static_cast<int>(pcm.size())) == 0) {
            const int count = whisper_full_n_segments(g_whisper_ctx);
            for (int i = 0; i < count; ++i) result += whisper_full_get_segment_text(g_whisper_ctx, i);
        }
    }
    env->ReleaseStringUTFChars(modelPath, model);
    env->ReleaseStringUTFChars(language, lang);
    return env->NewStringUTF(result.c_str());
}
